#ifndef CD_H
#define CD_H

#include "grafo_cidades.h"

// Função que verifica se a cidade é um CD
int eh_cd(int cidade_idx);

#endif // CD_H
